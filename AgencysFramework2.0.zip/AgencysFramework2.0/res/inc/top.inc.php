<!DOCTYPE html>
<html>
	<head>
		<title>AgencysFramework</title>
		<base href="<:var(SiteBaseDomain)/>" />
		<!--<link rel="stylesheet" type="text/css" media="screen" href="res/styles/bootstrap.min.css" />-->
		<link rel="stylesheet" type="text/css" media="screen" href="res/styles/cosmo.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="res/styles/main.css" />
		

		<script type="text/javascript" src="res/script/jq.js"></script>
		<script type="text/javascript" src="res/script/bootstrap.min.js"></script>
		<script type="text/javascript" src="res/script/main.js"></script>
		<meta charset="utf-8" />
	</head>
	<body>
	<nav class="navbar navbar-custom" role="navigation" style="width:990px;margin:auto">
		<ul class="nav navbar-nav">
			<li><a href="<:var(SiteDomain)/>Main">Main</a></li>
			<li><a href="<:var(SiteDomain)/>Login">Login</a></li>
		</ul>
</nav>