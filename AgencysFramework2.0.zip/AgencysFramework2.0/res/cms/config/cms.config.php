<?php
// Agencys CMS v1 — Config File
// Agencys CMS is a part of the AgencysFramework — (c) 2014 Agencys / Benjamin Rathelot
$CMS['enableCMS'] = false;
$CMS['enableAdmin'] = true;
