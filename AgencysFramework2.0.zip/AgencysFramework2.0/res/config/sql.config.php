<?php
// SQL Config --- Every features of the framework use this config file to connect to the database
$m_host = "localhost";
$m_user = "root";
$m_pwd = "";
$m_db = "default_database";
