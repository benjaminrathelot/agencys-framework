<?php
// SiteConfig
$SiteDomain = "http://localhost/lab/AgencysFramework2.0/index.php/";
$SiteDateFormat = "d/m/Y H:i";
$SiteDefaultLanguage = "en";
$SiteLanguagesList = array("en", "fr");
$SiteBaseDomain = explode("index.php", $SiteDomain);$SiteBaseDomain = $SiteBaseDomain[0];