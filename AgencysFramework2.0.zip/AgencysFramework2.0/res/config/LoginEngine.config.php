<?php
// LoginEngine config file

// --- Auth type
$loginEngineAuthType = "email";
//$loginEngineAuthType = "username";
//$loginEngineAuthType = "both";

// --- Auth URLs
$LoginEngineAlreadyOnlineURL = "";
$LoginEngineLoginFormURL = "Login";
$LoginEngineInvalidDataURL = "Login?inv";
$LoginEngineAuthOkURL = "Account";