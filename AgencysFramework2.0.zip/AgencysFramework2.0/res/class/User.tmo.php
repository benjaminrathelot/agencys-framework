<?php
if(!class_exists("UserTmo")) { class UserTmo{}}